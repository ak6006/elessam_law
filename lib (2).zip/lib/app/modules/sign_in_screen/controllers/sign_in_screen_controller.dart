import 'package:get/get.dart';

class SignInScreenController extends GetxController {
  //TODO: Implement SignInScreenController

  final count = 0.obs;
   final isLoading = false.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
