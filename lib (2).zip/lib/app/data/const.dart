// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors

import 'dart:convert';
// import 'dart:ui';
// import 'dart:ffi';

// import 'package:elessam_services/app/modules/home/attendance_model.dart';
// import 'package:elessam_services/app/modules/home/employee_dtata_model.dart';
// import 'package:elessam_services/app/modules/signInScreen/user_model.dart';
// import 'package:intl/intl.dart';
import 'package:elessam_law/app/data/ticketmessage.dart';

// import 'package:flutter/material.dart';
import 'package:odoo_rpc/odoo_rpc.dart';

// const primaryColor = Color.fromARGB(255, 247, 175, 109);
var orpc = OdooClient('https://100.elessam.com');
var session;

// List<Attendance> attendance = <Attendance>[];

// var subscription; //= orpc.sessionStream.listen(sessionChanged);
// var prev_session;
// List<Ticketmessage> globalticketMessage = <Ticketmessage>[];
Ticketmessage globalticketMessage =
    Ticketmessage(messages: [], messageCount: 0); // = <Ticketmessage>[];

dynamic globalticname;
List<int> globalwebsiteMessageIds = [];
// ignore: non_constant_identifier_names
dynamic globaltic_id;
dynamic globalprojectid;
dynamic globalrojectname;
dynamic globaltaskid;
dynamic globaltaskname;

Future<bool> login(String username, String password) async {
  try {
    session = await orpc.authenticate('elessam-15', username, password);
    //*//*print(session);

    return true;
  } catch (e) {
    return false;
  }
}

Future<dynamic> getmessageticketData(dynamic id) async {
  try {
    var res = await orpc.callKw({
      'model': 'mail.message', //.category',
      'method': 'search_read',
      'args': [],
      'kwargs': {
        'context': {'bin_size': true},
        'domain': [
          '&',
          [('res_id'), '=', (id)],
          [('subtype_id'), '=', 1]
        ],
        // 'domain': [
        //   ['res_id', '=', id] //session.userId
        // ],
        'fields': [
          'id',
          'body',
          'email_from',
          'reply_to',
          'subject',
          'author_id',
          'create_uid',
          'message_id',
          'res_id',
          'date',
          'message_type',
          'subtype_id',
          'model',
          'notified_partner_ids',
          'notification_ids',
          'parent_id',
          // 'tracking_value_ids',
        ],
      },
    });
    //*print(jsonEncode(res));
    // ticketMessage = (ticketmessageFromJson(jsonEncode(res)));
    return jsonEncode(res);
  } catch (e) {
    print(e);
    return false;
  }
}

Future<dynamic> get_ticket_data() async {
  try {
    var res = await orpc.callKw({
      'model': 'helpdesk.ticket', //.category',
      'method': 'search_read',
      'args': [],
      'kwargs': {
        'context': {'bin_size': true},
        // 'domain': [
        //   ['user_id', '=', userid] //session.userId
        // ],
        'fields': [
          'id',
          'name',
          'stage_id',
          'partner_id',
          'category_id',
          'description',
          'create_date',
          'website_message_ids'
          // 'message_partner_ids'
        ],
      },
    });
    //*print(jsonEncode(res));
    // employeeData = (employeeDtataFromJson(jsonEncode(res)));
    // ticketModel = (ticketModelFromJson)(jsonEncode(res));
    return jsonEncode(res);
  } catch (e) {
    print(e);
    return false;
  }
}
